<?php
include_once 'dbconfig.php';
?>
<!DOCTYPE html>
<html>
<head>
<title>File Uploading</title>
</head>
<body>

	<form action="upload.php" method="post" enctype="multipart/form-data">
	<input type="file" name="file" />
	<button type="submit" name="btn-upload">Upload</button>
	</form>
    <br/><br/>
 
    <?php
	if(isset($_GET['success']))
	{
		?>
        <label>File Uploaded Successfully...</label>
        <?php
	}
	else if(isset($_GET['fail']))
	{
		?>
        <label>Problem While File Uploading !</label>
        <?php
	}
	else
	{
		?>
        <label>Upload any files.</label>
        <?php
	}
	?>
	<br><br>
	 <a href="view.php">Click here to view file.</a>

</body>
</html>